<?php
// --- JUNO LOGIC (No Changes) ---
$host = "localhost";
$user = "root";
$pass = "";
$db_name = "flavor_fusion_db"; 
$conn = new mysqli($host, $user, $pass, $db_name);

$staff_id = 8; 

if (isset($_POST['update_status'])) {
    $oid = $_POST['order_id'];
    $nst = $_POST['new_status'];
    $conn->query("UPDATE orders SET status = '$nst' WHERE id = '$oid'");
    echo "<script>alert('Status Updated!'); window.location.href='dashboard.php';</script>";
}

if (isset($_POST['save_profile'])) {
    $u_name = $_POST['u_name'];
    $u_email = $_POST['u_email'];
    $u_phone = $_POST['u_phone'];
    $conn->query("UPDATE users SET name='$u_name', email='$u_email', phone='$u_phone' WHERE id='$staff_id'");
    echo "<script>alert('Profile Updated!'); window.location.href='dashboard.php?view=profile';</script>";
}

$staff = $conn->query("SELECT * FROM users WHERE id = '$staff_id'")->fetch_assoc();
$activeVal = $conn->query("SELECT COUNT(*) FROM orders WHERE status IN ('pending', 'processing')")->fetch_row()[0];
$doneVal   = $conn->query("SELECT COUNT(*) FROM orders WHERE status = 'completed'")->fetch_row()[0];
$totalEarnings = $conn->query("SELECT SUM(total_amount) FROM orders WHERE status = 'completed'")->fetch_row()[0] ?? 0;

$view = isset($_GET['view']) ? $_GET['view'] : 'dashboard';
$filter = ($view == 'active') ? " WHERE o.status IN ('pending', 'processing')" : (($view == 'completed') ? " WHERE o.status = 'completed'" : "");
$result = $conn->query("SELECT o.*, u.name as c_name FROM orders o LEFT JOIN users u ON o.user_id = u.id $filter ORDER BY o.id DESC");
?>

<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <title>Staff Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* NEW COLOR PALETTE - FROM SCREENSHOT */
        :root { 
            --navy: #242e4c; 
            --fusion-green: #97c15c; 
            --light-bg: #f8f9fc; 
        }

        body { background: var(--light-bg); font-family: 'Segoe UI', sans-serif; }
        
        /* Sidebar Styles */
        .sidebar { height: 100vh; width: 260px; position: fixed; background: var(--navy); color: white; }
        .sidebar-header { padding: 30px 20px; font-size: 22px; font-weight: bold; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-header span { color: var(--fusion-green); }
        .sidebar-link { padding: 15px 25px; color: #d1d5db; text-decoration: none; display: flex; align-items: center; transition: 0.3s; }
        .sidebar-link:hover { background: #2f3a5d; color: white; }
        .active-link { background: var(--fusion-green) !important; color: white !important; }
        
        /* Content & Cards */
        .main-content { margin-left: 260px; padding: 40px; }
        .stat-card { background: white; border: none; border-radius: 8px; padding: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border-left: 5px solid var(--fusion-green); }
        
        /* Profile Form Center Alignment */
        .profile-container { max-width: 600px; margin: 0 auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
        
        /* Buttons */
        .btn-fusion { background: var(--fusion-green); color: white; border: none; font-weight: bold; }
        .btn-fusion:hover { background: #86ad52; color: white; }
        .btn-outline-fusion { border: 1px solid var(--fusion-green); color: var(--fusion-green); }
        .btn-outline-fusion:hover { background: var(--fusion-green); color: white; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">Flavor<span>Fusion</span></div>
    <div class="mt-3">
        <a href="dashboard.php" class="sidebar-link <?= ($view=='dashboard')?'active-link':'' ?>"><i class="fas fa-th-large me-2"></i> Dashboard</a>
        <a href="dashboard.php?view=active" class="sidebar-link <?= ($view=='active')?'active-link':'' ?>"><i class="fas fa-box me-2"></i> Active Orders</a>
        <a href="dashboard.php?view=completed" class="sidebar-link <?= ($view=='completed')?'active-link':'' ?>"><i class="fas fa-check-circle me-2"></i> Completed</a>
        <a href="dashboard.php?view=profile" class="sidebar-link <?= ($view=='profile')?'active-link':'' ?>"><i class="fas fa-user-edit me-2"></i> Edit Profile</a>
        <a href="?action=logout" class="sidebar-link text-danger mt-5"><i class="fas fa-sign-out-alt me-2"></i> Logout</a>
    </div>
</div>

<div class="main-content">
    <?php if ($view == 'profile'): ?>
        <h3 class="fw-bold mb-4 text-secondary">Profile Settings</h3>
        <div class="profile-container">
            <div class="text-center mb-4">
                <i class="fas fa-user-circle fa-4x text-light mb-2"></i>
                <h5 class="fw-bold text-dark">Personal Information</h5>
            </div>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">FULL NAME</label>
                    <input type="text" name="u_name" class="form-control" value="<?= $staff['name'] ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold text-muted">EMAIL ADDRESS</label>
                    <input type="email" name="u_email" class="form-control" value="<?= $staff['email'] ?>" required>
                </div>
                <div class="mb-4">
                    <label class="form-label small fw-bold text-muted">PHONE NUMBER</label>
                    <input type="text" name="u_phone" class="form-control" value="<?= $staff['phone'] ?? '8529637410' ?>">
                </div>
                <button type="submit" name="save_profile" class="btn btn-fusion w-100 py-3">SAVE CHANGES</button>
            </form>
        </div>
    <?php else: ?>
        <h3 class="fw-bold mb-4 text-secondary">Dashboard</h3>
        <div class="row g-4 mb-5">
            <div class="col-md-4"><div class="stat-card"><h6>Active</h6><h2 class="fw-bold text-navy"><?= $activeVal ?></h2></div></div>
            <div class="col-md-4"><div class="stat-card"><h6>Completed</h6><h2 class="fw-bold text-navy"><?= $doneVal ?></h2></div></div>
            <div class="col-md-4"><div class="stat-card"><h6>Earnings</h6><h2 class="fw-bold text-navy">₹<?= number_format($totalEarnings, 2) ?></h2></div></div>
        </div>

        <div class="card border-0 shadow-sm rounded-3 p-4">
            <h5 class="fw-bold mb-4">Recent Orders</h5>
            <table class="table align-middle">
                <thead class="table-light">
                    <tr><th>ID</th><th>Customer</th><th>Status</th><th>Action</th></tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td class="fw-bold">#<?= $row['id'] ?></td>
                        <td><?= $row['c_name'] ?></td>
                        <td><span class="badge" style="background: rgba(151,193,92,0.1); color: var(--fusion-green);"><?= $row['status'] ?></span></td>
                        <td><button class="btn btn-sm btn-outline-fusion px-3" data-bs-toggle="modal" data-bs-target="#m<?= $row['id'] ?>">Update</button></td>
                    </tr>
                    
                    <div class="modal fade" id="m<?= $row['id'] ?>" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <form method="POST" class="modal-content border-0">
                                <div class="modal-body p-4 text-center">
                                    <h5 class="fw-bold mb-3">Order Status #<?= $row['id'] ?></h5>
                                    <input type="hidden" name="order_id" value="<?= $row['id'] ?>">
                                    <select name="new_status" class="form-select mb-4">
                                        <option value="pending" <?= ($row['status']=='pending')?'selected':'' ?>>Pending</option>
                                        <option value="processing" <?= ($row['status']=='processing')?'selected':'' ?>>Processing</option>
                                        <option value="completed" <?= ($row['status']=='completed')?'selected':'' ?>>Completed</option>
                                    </select>
                                    <button type="submit" name="update_status" class="btn btn-fusion w-100 py-2">UPDATE STATUS</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>